/**
 * Created by mac on 04/09/19.
 */
(function() {

    $('.form-prevent-multiple-submits').on('submit', function() {
        $('.button-prevent-multiple-submits').attr('disabled', 'true');
    });

})();
