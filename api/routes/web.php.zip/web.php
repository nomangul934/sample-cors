<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    if(Auth::check()){
        if(Auth::user()->role === 'school') return redirect()->route('school.fairs_list');
        if(Auth::user()->role === 'university') return redirect()->route('university.invitations_list');
        if(Auth::user()->role === 'admin') return redirect()->route('admin.manage_university');
    }
    return redirect('/login');
});

Auth::routes();
Route::get('/university/register', 'Auth\RegisterUniversityController@showRegistrationForm')->name('register_university');
Route::post('/university/register', 'Auth\RegisterUniversityController@register');

// import universities routes
Route::get('/university/import', 'University\ImportController@importPage')->name('import_universities_page');
Route::post('/university/import', 'University\ImportController@import')->name('import_universities');


Route::middleware('auth')->namespace('Auth')->group(function() {
    Route::get('/change-password', 'ChangePasswordController@change_pwd_page')->name('change_password_page');
    Route::post('/change-password', 'ChangePasswordController@change_pwd')->name('change_password');
});

Route::middleware('school')->prefix('school')->namespace('School')->name('school.')->group(function () {
    Route::get('/profile', 'ProfileController@update')->name('update_profile');
    Route::post('/profile', 'ProfileController@edit')->name('edit_profile');

    Route::get('/fairs', 'FairController@index')->name('fairs_list');
    Route::get('/fairs/create', 'FairController@create')->name('create_fair');
    Route::post('fairs', 'FairController@store')->name('store_fair');
    Route::get('/fairs/edit/{id}', 'FairController@edit')->name('edit_fair');
    Route::post('fairs/{id}', 'FairController@update')->name('update_fair');
    Route::get('/fairs/{id}/participants', 'FairController@participants')->name('fair_participants');

    Route::get('/univ_lists', 'UniversityController@index')->name('univ_lists');
    Route::get('/counselor_lists', 'CounselorController@index')->name('counselor_lists');
    Route::post('/update_counselor/{id}', 'CounselorController@update')->name('update_counselor');
});

Route::middleware('university')->prefix('university')->namespace('University')->name('university.')->group(function () {
    Route::get('/invitations', 'InvitationController@index')->name('invitations_list');
    Route::get('/invitations/{id}/accept', 'InvitationController@accept')->name('accept_invitation');
    Route::get('/invitations/{id}/reject', 'InvitationController@reject')->name('reject_invitation');
    Route::get('/schools', 'SchoolController@index')->name('schools_list');
    Route::get('/schools/{id}', 'SchoolController@show')->name('school_details');

    Route::get('/profile', 'ProfileController@update')->name('update_profile');
    Route::post('/profile', 'ProfileController@edit')->name('edit_profile');

    Route::get('/users_list', 'UsersController@index')->name('users_list');
    Route::post('/add_user', 'UsersController@add')->name('add_user');
});
Route::middleware('admin')->prefix('admin')->namespace('Admin')->name('admin.')->group(function() {
    Route::get('/manage_university','ManageUniversityController@index')->name('manage_university');
    Route::get('/edit_univ/{id}','ManageUniversityController@edit')->name('edit_univ');
    Route::post('/update_univ/{id}','ManageUniversityController@update')->name('update_univ');
    Route::post('/suspend','ManageUniversityController@suspend')->name('suspend');
    Route::post('/suspend1','ManageUniversityController@suspend1')->name('suspend1');
    Route::get('/manage_school','ManageSchoolController@index')->name('manage_school');
    Route::get('/add_school','ManageSchoolController@create')->name('add_school');
    Route::post('/store_school','ManageSchoolController@store')->name('store_school');
    Route::get('/edit_school/{id}','ManageSchoolController@edit')->name('edit_school');
    Route::post('/update_school/{id}','ManageSchoolController@update')->name('update_school');

    Route::get('/manage_users','ManageUsersController@index')->name('manage_users');
    Route::get('/add_user','ManageUsersController@add')->name('add_user');

    Route::get('/manage_fairs','ManageFairsController@index')->name('manage_fairs');
    Route::get('/edit_fair/{id}','ManageFairsController@edit')->name('edit_fair');
    Route::post('/update_fair/{id}','ManageFairsController@update')->name('update_fair');
    Route::get('/delete_fair/{id}','ManageFairsController@delete')->name('delete_fair');
});

Route::get('/invitation/register', 'University\InvitationController@register_from_mail')->name('university_invitation_register');

