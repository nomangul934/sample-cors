<?php

namespace App\Http\Controllers\University;

use App\Models\Invitation;
use App\Models\University;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
//added by @Prasad
use Carbon\Carbon;
use App\Models\School;
use App\Mail\UnviersityConfirmFairMail;
use Illuminate\Support\Facades\Mail;
class InvitationController extends Controller
{
    /**
     * get invitations list for connected university
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request) {
        //$invitations = Invitation::where('university_id', Auth::user()->university->id)->get();
        $invitations = Invitation::where('university_id', Auth::user()->university_id)->get();
        $university = University::where('id',Auth::user()->university_id)->get()->first();
        return view('university.invitation.index', compact('invitations','university'));
    }

    /**
     * Accept invitation
     *
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function accept($id) {
        $invitation = Invitation::find($id);

        if($invitation == null){
            return redirect()->route('university.invitations_list')->with([
                'error' => true,
                'message' => 'Invitation not found !'
            ]);
        }
        if($invitation->university->id != Auth::user()->university_id){
            return redirect()->route('university.invitations_list')->with([
                'error' => true,
                'message' => 'You are not allowed to register for this fair !'
            ]);
        }

        $fair = $invitation->fair;

        $count = University::whereHas('invitations', function($query) use ($fair){
            $query->where('accepted', true)->where('fair_id', $fair->id);
        })->count();
        
        if($count < $fair->universities_max) {
            $invitation->accepted = true;
            $invitation->rejected = false;
            $invitation->save();

            $error = false;
            $message = 'You successfully registered !';
        }else{
            $error = true;
            $message = 'Registered universities maximum number reached !';
        }


        //Updated by @Prasad
        //Send notification to University about Fair 
        // if ($error == false) $this->sendNotifyToUniversity($fair);


        return redirect()->route('university.invitations_list')->with([
            'error' => $error,
            'message' => $message
        ]);
    }
    /**
     * Send email notification to University
     *
     */
    public function sendNotifyToUniversity($fair) {
        $university_email = Auth::user()->email;
        $school = School::where('id',$fair->school_id)->get()->first();
        //get google map link     
        $googlemaplink = 'Google Map Link';      
        if ($school->latitude!='' && $school->longitude != '') {
            $googlemaplink = "https://maps.google.com/?ll=".$school->latitude.','.$school->longitude;
        } else {
            $googlemaplink = "https://maps.google.com/?q=".$school->address1.','.$school->address2.','.$school->city.','.$school->country;
        }
      
        $email_content = array(
            'schoolname' => $school->name,
            'startdate' => Carbon::createFromFormat('Y-m-d H:i:s', $fair->start_date)->format('Y-m-d H:i'),
            'starttime' => Carbon::createFromFormat('Y-m-d H:i:s', $fair->start_date)->format('H:i a'),
            'enddate'=> Carbon::createFromFormat('Y-m-d H:i:s', $fair->end_date)->format('Y-m-d H:i'),
            'endtime'=> Carbon::createFromFormat('Y-m-d H:i:s', $fair->end_date)->format('H:i a'),
            'googlemaplink'=>$googlemaplink
        );
        Mail::to($university_email)->send(new UnviersityConfirmFairMail($email_content));

    }

    /**
     * Reject invitation
     *
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function reject($id) {
        $invitation = Invitation::find($id);

        if($invitation == null){
            return redirect()->route('university.invitations_list')->with([
                'error' => true,
                'message' => 'Invitation not found !'
            ]);
        }

        if($invitation->university->id != Auth::user()->university_id){
            return redirect()->route('university.invitations_list')->with([
                'error' => true,
                'message' => 'You are not allowed to reject this fair !'
            ]);
        }

        $invitation->rejected = true;
        $invitation->accepted = false;
        $invitation->save();

        return redirect()->route('university.invitations_list')->with([
            'error' => false,
            'message' => 'Successfully rejected !'
        ]);
    }

    /**
     * Register university for a fair from mail without authentication
     *
     * @param Request $request
     * @return $this
     */
    public function register_from_mail(Request $request) {

        if (! $request->hasValidSignature()) {
            abort(403);
        }

        Auth::loginUsingId($request->input('user_id'));

        $id = $request->input('invitation_id');
        $invitation = Invitation::find($id);

        if($invitation == null){
            return redirect()->route('university.invitations_list')->with([
                'error' => true,
                'message' => 'Invitation not found !'
            ]);
        }

        $fair = $invitation->fair;

        $count = University::whereHas('invitations', function($query) use ($fair){
            $query->where('accepted', true)->where('fair_id', $fair->id);
        })->count();

        if($count < $fair->universities_max) {
            $invitation->accepted = true;
            $invitation->rejected = false;
            $invitation->save();

            $error = false;
            $message = 'You successfully registered !';
        }else{
            $error = true;
            $message = 'Registered universities maximum number reached !';
        }

        return redirect()->route('university.invitations_list')->with([
            'error' => $error,
            'message' => $message
        ]);
    }
}
