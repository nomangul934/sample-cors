<?php

namespace App\Http\Controllers\School;

use App\Models\Curriculum;
use App\Models\School;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
    public function update () {

        $school = School::find(Auth::user()->school_id);    
        $schooluser = Auth::user();           
        $curricula = Curriculum::all();

        return view('school.profile', compact(['school', 'curricula','schooluser']));
    }

    public function edit(Request $request) {

        $validator = Validator::make($request->all(), [
            'name' => ['bail', 'required', 'string', 'max:255'],
            'school_name' => ['bail', 'required', 'string', 'max:255'],
            'phone' => ['bail', 'required', 'regex:/(0)[0-9]{9}/'],
            'school_phone' => ['bail', 'nullable', 'regex:/(0)[0-9]{9}/'],
            'school_email' => ['bail', 'nullable', 'string', 'email', 'max:255'],
            'logo' => [
                'bail', 'image', 'max:2048'
            ],
            'address1' => ['bail', 'required'],
            'address2' => ['bail', 'required'],
            'country' => ['bail', 'required'],
            'city' => ['bail', 'required'],
            'curriculum' => ['bail', 'required'],
            'fees_grade11' => ['bail', 'required', 'integer'],
            'fees_grade12' => ['bail', 'required', 'integer']
        ]);

        if ($validator->fails()) {
            return redirect()->route('school.update_profile')
                ->withErrors($validator)
                ->withInput();
        }

        // update user info
        $user = Auth::user();
        $user->name = $request->get('name');
        $user->phone = $request->get('phone');

        if($request->logo) {
            $imageName = time().'.'.$request->logo->getClientOriginalExtension();
            $request->logo->move(public_path('images'), $imageName);
            $user->logo = $imageName;
        }

        $user->save();

        // update school info
        //$school = $user->school;
        $school = School::find($user->school_id);
        $school->name = $request->get('school_name');
        $school->email = $request->get('school_email');
        $school->phone = $request->get('school_phone');
        $school->website = $request->get('school_website');
        $school->address1 = $request->get('address1');
        $school->address2 = $request->get('address2');
        $school->country = $request->get('country');
        $school->city = $request->get('city');
        $school->latitude = $request->get('latitude');
        $school->longitude = $request->get('longitude');
        $school->about_us = $request->get('about_us');
        $school->full_profile = $request->get('full_profile');
        $school->curriculum_id = $request->get('curriculum');
        $school->fees_grade11 = $request->get('fees_grade11');
        $school->fees_grade12 = $request->get('fees_grade12');

        $school->save();

        return back()->with(['message' => 'Profile updated successfully !']);

    }
}
