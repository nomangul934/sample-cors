<?php

namespace App\Http\Controllers\School;
use Illuminate\Support\Facades\DB;
use App\Models\Fair;
use App\Models\University;
use App\Models\Counselor;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class CounselorController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $counselor = Counselor::where('school_id',Auth::user()->school_id)->get();
        $school = School::where('id', Auth::user()->school_id)->get()->first();
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        return view('school.counselor.index', compact(['counselor','school','query','fairs']));

    }

    public function update(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            'full_name' => 'required',            
            'mobile' => 'required',
            'email' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('school.counselor_lists')
                ->withErrors($validator)
                ->withInput();
        }

        $full_name = json_encode($request->get('full_name'));
        $mobile = json_encode($request->get('mobile'));
        $email = json_encode($request->get('email'));

        //var_dump($id);exit;
        //var_dump($id);exit;

        $counselor = Counselor::where('school_id',$id)->get();

        if(sizeof($counselor)){
            Counselor::where('school_id', $id)
                        ->update([
                            'full_name' => $full_name,
                            'mobile' => $mobile,
                            'email' => $email,
                            'school_id' => $id,
                        ]);
        }else{
            Counselor::create([
                'full_name' => $full_name,
                'mobile' => $mobile,
                'email' => $email,
                'school_id' => $id,
                
            ]);
        }

        return redirect()->route('school.counselor_lists')->with([
            'error' => false,
            'message' => 'Counselor updated successfully !'
        ]);

    }

}
