<?php

namespace App\Http\Controllers\Admin;

use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class ManageUsersController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $users = User::get();
        return view('admin.manage_users.index', compact(['users']));

    }

    public function add() {

        $users = User::get();
        $universities = University::get();
        $schools = School::get();
        return view('admin.manage_users.add_user', compact(['users','universities','schools']));

    }

    
}
