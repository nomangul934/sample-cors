<?php

namespace App\Http\Controllers\Admin;

use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class ManageFairsController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {
        $schools = School::get();
        $fairs = Fair::get();
        return view('admin.manage_fairs.index', compact(['fairs','schools']));

    }

    public function edit($id) {
        $fair = Fair::where('id', $id)->get();
        $schools = School::get();
        return view('admin.manage_fairs.edit', compact(['fair','schools']));
    }

    public function delete($id) {
        
        Fair::where('id',$id)->delete();
        Invitation::where('fair_id',$id)->delete();
        return redirect()->route('admin.manage_fairs')->with([
            'error' => false,
        'message' => 'Fair deleted successfully !']);
    }

    public function update(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            'school_name' => 'required',
            'start_date' => 'bail|required|date',
            'end_date' => 'bail|required|date|after_or_equal:start_date',
            'students_grade12_number' => 'bail|required|numeric|min:1',
            'students_grade11_number' => 'bail|required|numeric|min:1',
            'universities_max' => 'bail|required|numeric|min:1'
        ]);

        if ($validator->fails()) {
            return redirect()->route('admin.edit_fair', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } 

        $school_id = $request->get('school_id');
       
        $start_date = $request->get('start_date');
        $end_date = $request->get('end_date');
        
        $fair = Fair::where('id',$id)
            ->update([
                'school_id' => $school_id,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'students_grade12_number' => $request->get('students_grade12_number'),
                'students_grade11_number' => $request->get('students_grade11_number'),
                'universities_max' => $request->get('universities_max'),
            ]);

        return redirect()->route('admin.manage_fairs')->with([
            'error' => false,
            'message' => 'Fair updated successfully !'
        ]);

        //Updated by @Prasad
        //Send notification to all Universities using mail
        $this->sendNotifyToUniversities($fair);
    }
    
}
