<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\DB;
use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class ManageSchoolController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $schools = School::get();
        $universities = University::get();
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        return view('admin.manage_school.index', compact(['fairs','schools','universities','query']));

    }

    public function create() {
        $school = School::get();
        return view('admin.manage_school.add_school', compact(['school']));
    }

    public function edit($id) {
        $school = School::where('id',$id)->get();
        return view('admin.manage_school.edit_school', compact(['school']));
    }

    public function store(Request $request) {

        $validator = Validator::make($request->all(), [
            'school_name' => 'required',            
            'phone' => 'required',
            'email' => 'required',
            'website' => 'required',
            'map_link' => 'required',
            
        ]);

        if ($validator->fails()) {
            return redirect()->route('admin.add_school')
                ->withErrors($validator)
                ->withInput();
        }

        $school_name = $request->get('school_name');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $website = $request->get('website');
        $map_link = $request->get('map_link');

        $compus = json_encode($request->get('compus'));
        $country = json_encode($request->get('country'));
        $city = json_encode($request->get('city'));
        $address = json_encode($request->get('address'));
        
        School::create([
            'name' => $school_name,
            'email' => $email,
            'phone' => $phone,
            'website' => $website,
            'map_link' => $map_link,
            'compus' => $compus,
            'country' => $country,
            'city' => $city,
            'address1' => $address,
            'user_id' => Auth::user()->id
        ]);

        return redirect()->route('admin.manage_school')->with([
            'error' => false,
            'message' => 'School created successfully !'
        ]);
    }

    public function update(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            'school_name' => 'required',            
            'phone' => 'required',
            'email' => 'required',
            'website' => 'required',
            'map_link' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('admin.edit_school', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        }

        $school_name = $request->get('school_name');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $website = $request->get('website');
        $map_link = $request->get('map_link');

        $compus = json_encode($request->get('compus'));
        $country = json_encode($request->get('country'));
        $city = json_encode($request->get('city'));
        $address = json_encode($request->get('address'));

        $fair = School::where('id', $id)
            ->update([
                'name' => $school_name,
                'email' => $email,
                'phone' => $phone,
                'website' => $website,
                'map_link' => $map_link,
                'compus' => $compus,
                'country' => $country,
                'city' => $city,
                'address1' => $address,
                'user_id' => Auth::user()->id
            ]);

        return redirect()->route('admin.manage_school')->with([
            'error' => false,
            'message' => 'Fair updated successfully !'
        ]);

        //Updated by @Prasad
        //Send notification to all Universities using mail
        $this->sendNotifyToUniversities($school);
    }

    
}
