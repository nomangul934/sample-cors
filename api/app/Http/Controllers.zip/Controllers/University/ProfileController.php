<?php

namespace App\Http\Controllers\University;

use App\Models\Curriculum;
use App\Models\School;
use App\Models\University;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
    public function update () {

        $university = University::find(Auth::user()->university_id);    
        $university_user = Auth::user();           

        $univ = University::where('id',Auth::user()->university_id)->get();

        return view('university.profile', compact(['university', 'univ','university_user']));
    }

    public function edit(Request $request) {

        $university_user = Auth::user();

        $validator = Validator::make($request->all(), [
            'univ_name' => 'required',            
            'phone' => 'required',
            'email' => 'required',
            'website' => 'required',
            'map_link' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('university.update_profile')
                ->withErrors($validator)
                ->withInput();
        }

        $univ_name = $request->get('univ_name');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $website = $request->get('website');
        $map_link = $request->get('map_link');

        $compus = json_encode($request->get('compus'));
        $country = json_encode($request->get('country'));
        $city = json_encode($request->get('city'));
        $address = json_encode($request->get('address'));

        $university = University::where('id', $university_user->university_id)
            ->update([
                'name' => $univ_name,
                'email' => $email,
                'phone' => $phone,
                'website' => $website,
                'map_link' => $map_link,
                'compus' => $compus,
                'country' => $country,
                'city' => $city,
                'address' => $address,
                'user_id' => Auth::user()->id
            ]);

        return redirect()->route('university.update_profile')->with([
            'error' => false,
            'message' => 'Profile updated successfully !'
        ]);

        // return back()->with(['message' => 'Profile updated successfully !']);

    }
}
