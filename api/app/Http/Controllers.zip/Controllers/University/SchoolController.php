<?php

namespace App\Http\Controllers\University;
use Illuminate\Support\Facades\Auth;
use App\Models\School;
use App\Models\University;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SchoolController extends Controller
{
    /**
     * List of all system schools
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index() {
        $schools = School::select('schools.*','users.name as contactname',
                        'users.email as contactemail','users.phone as contactphone')
                    ->leftjoin('users', 'users.school_id','=','schools.id')
                    ->where('users.role','school')
                    ->get();
        $university = University::where('id',Auth::user()->university_id)->get()->first();
        return view('university.school.index', compact('schools','university'));
    }

    /**
     * Show a school details
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show($id) {
        $school = School::find($id);

        return view('university.school.show', compact('school'));
    }
}
