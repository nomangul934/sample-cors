<?php

namespace App\Http\Controllers\Admin;

use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class ManageUniversityController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $universities = University::get();
        return view('admin.manage_university.index', compact(['fairs','school','universities']));

    }

    public function edit($id) {
        $univ = University::where('id',$id)->get();
        return view('admin.manage_university.edit_university', compact(['univ']));
    }

    public function update(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            'univ_name' => 'required',            
            'phone' => 'required',
            'email' => 'required',
            'website' => 'required',
            'map_link' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('admin.edit_univ', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        }

        $univ_name = $request->get('univ_name');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $website = $request->get('website');
        $map_link = $request->get('map_link');

        $compus = json_encode($request->get('compus'));
        $country = json_encode($request->get('country'));
        $city = json_encode($request->get('city'));
        $address = json_encode($request->get('address'));

        $fair = University::where('id', $id)
            ->update([
                'name' => $univ_name,
                'email' => $email,
                'phone' => $phone,
                'website' => $website,
                'map_link' => $map_link,
                'compus' => $compus,
                'country' => $country,
                'city' => $city,
                'address' => $address,
                'user_id' => Auth::user()->id
            ]);

        return redirect()->route('admin.manage_university')->with([
            'error' => false,
            'message' => 'Fair updated successfully !'
        ]);

        //Updated by @Prasad
        //Send notification to all Universities using mail
        $this->sendNotifyToUniversities($university);
    }


    
}
